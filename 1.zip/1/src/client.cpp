#include <winsock2.h>
#include <ws2tcpip.h>
#include <iphlpapi.h>
#include <stdio.h>

#pragma comment(lib, "Ws2_32.lib")
//------------------------------------------------------------------------------
#include "./async-sockets-cpp/include/tcpsocket.hpp"
#include <iostream>
#include <string>

#include <conio.h>
#include <iostream>
//------------------------------------------------------------------------------
#include <csignal>
#include <cstdlib>
#include <cstring>

#include <vector>

//#include <unistd.h>
#include <io.h>
#include <stdio.h>
#include <iostream>
#include <signal.h>
#include <ctime>

#include "srec.h"
using namespace std;
static TCPSocket* _tcpSocket = 0;

void send_file(TCPSocket &tcpSocket, const std::string& IP, int UDP_port, const std::string& Folder,
    const std::string& file_name, int confirmation_timeout);

int tcpSocket_main(const std::string &IP, int Port, int UDP_port, const std::string &Folder, 
    const std::string &Filename, int confirmation_timeout)
{
    // Initialize socket.
    TCPSocket tcpSocket([](int errorCode, std::string errorMessage) {
        cout << "Socket creation error:" << errorCode << " : " << errorMessage << endl;
        });

    _tcpSocket = &tcpSocket;
    // Start receiving from the host.
    
    tcpSocket.onMessageReceived = NULL;
    
    
    // On socket closed:
    tcpSocket.onSocketClosed = [](int errorCode) {
        cout << "Connection closed: " << errorCode << endl;
    };

    // Connect to the host.
    tcpSocket.Connect(IP, Port, [&] {
        cout << "Connected to the server successfully." << endl;

        std::string send_message = std::to_string(UDP_port) + "\r\n";
        // Send String:
        tcpSocket.Send(send_message);
        send_message = Filename + "\r\n";
        tcpSocket.Send(send_message);

        },
        [](int errorCode, std::string errorMessage) {
            // CONNECTION FAILED
            cout << errorCode << " : " << errorMessage << endl;
        });
 
    send_file(tcpSocket, IP, UDP_port, Folder,
        Filename, confirmation_timeout);

    tcpSocket.Close();

    return 0;
}
#include <iostream>
//------------------------------------------------------------------------------

static void clean_this()
{
    if (_tcpSocket != NULL)
    {
        _tcpSocket->Close();
        WSACleanup();
    }
}
// The actual signal handler
void handleSignal(int sig) {
    // Cannot use printf() - not async-signal-safe 
    // For simplicity I use a single call to write here
    // though it is not guaranteed to write the whole message
    // You need to wrap it in a loop

    // Die only on Ctrl+C
    if (sig == SIGINT) {
        const char* msg = "Die\n";
        write(2, msg, ::strlen(msg));
        // Reset to use the default handler to do proper clean-up
        // If you want to call the default handler for every singal
        // You can avoid the call below by adding SA_RESETHAND to sa_flags

        clean_this();

        signal(sig, SIG_DFL);
        raise(sig);
        return;
    }

    // Here we want to handle the signal ourselves
    // We have all the info available
    const char* msg = "Continue\n";
    write(2, msg, ::strlen(msg));
}
int main(int argc, char* argv[]) {
    // A vector of all signals that lead to process termination by default
  // (see man -s 7 signal)
    const int TERM_SIGNALS[] = {
           SIGINT, SIGILL, SIGABRT, SIGFPE, SIGSEGV,
           SIGTERM };

    // Register the signal event handler for every terminating signal
    for (auto sig : TERM_SIGNALS) {
        signal(sig, handleSignal);
    }

    std::string IP;
    int Port;
    //������ - ���� ��� �������� UDP �������.
    int UDP_port;
    //��������� - ���� � �����.    
    std::string Folder_and_filename;
    std::string Folder;
    std::string Filename;
    //����� - ������� �� ������������� UDP        ������� � ������������.
    int confirmation_timeout;

    if (argc != 6)
    {
        std::cout << "Get files from udp port\n";
        std::cout << "Usage:\n" << argv[0] << " server_ip_adress server_port UDP_port file_path confirmation_timeout\n";
        exit(-1);
    }

    IP = argv[1];
    Port = atoi(argv[2]);
    UDP_port = atoi(argv[3]);
    Folder_and_filename = argv[4];
    int position = 0;

    if ((position = Folder_and_filename.rfind("\\")) != string::npos)
    {
        Filename = Folder_and_filename.substr(position, Folder_and_filename.size() - position);
        Folder = Folder_and_filename.substr(0, position+1);
    }
    else
        Filename = Folder_and_filename;

    confirmation_timeout = atoi(argv[5]);

    std::cout << "ip: " << IP << "\n";
    std::cout << "port: " << Port << "\n";
    std::cout << "udp port: " << UDP_port << "\n";
    std::cout << "file path: " << Folder_and_filename << "\n";
    std::cout << "folder: " << Folder << "\n";
    std::cout << "file name: " << Filename << "\n";
    std::cout << "confirmation timeout: " << confirmation_timeout << "\n";

    // Initialize Winsock
    WSADATA wsaData;
    int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != 0) {
        printf("WSAStartup failed with error: %d\n", iResult);
        return 1;
    }
    //std::cin.ignore();

    tcpSocket_main(IP, Port, UDP_port, Folder, Filename, confirmation_timeout);
}
 
__int64 FileSize(const wchar_t* name)
{
    WIN32_FILE_ATTRIBUTE_DATA fad;
    if (!GetFileAttributesEx(name, GetFileExInfoStandard, &fad))
        return -1; // error condition, could call GetLastError to find out more
    LARGE_INTEGER size;
    size.HighPart = fad.nFileSizeHigh;
    size.LowPart = fad.nFileSizeLow;
    return size.QuadPart;
}

bool send_segment_message(TCPSocket& tcpSocket, SOCKET &s, SOCKADDR_IN &sa, const std::string& send_message,
    int confirmation_timeout, unsigned int addrL);

void send_file(TCPSocket &tcpSocket, const std::string& IP, int UDP_port, const std::string& Folder,
    const std::string& file_name, int confirmation_timeout)
{
    SOCKET s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (s == INVALID_SOCKET)
    {
        std::cout << "socket error" << std::endl;
        return;
    }

    SOCKADDR_IN sa{};
    sa.sin_family = AF_INET;
    sa.sin_port = htons(UDP_port);
    sa.sin_addr.S_un.S_addr = inet_addr(IP.c_str());

    std::string message;

    char* file_buffer = NULL;
    int file_buffer_size = 0;

    //
    // The call to fopen is deferred until the constructor has
    // completed.  This is so that the virtual is_binary() method
    // is available (it isn't in the base class constructor).
    //        


    std::string File_name = Folder + file_name;
    FILE* vfp = fopen(File_name.c_str(), "rb");
    if (!vfp)
        perror("Error: open file_name");


    int size = FileSize(std::wstring(File_name.begin(), File_name.end()).c_str());

    if (size < 10 * 1024 * 1024)
        if (file_buffer == NULL)
        {
            file_buffer = new char[size];
            file_buffer_size = size;
        }
    if (fseek(vfp, 0L, SEEK_SET) == 0)
    {
        fread(file_buffer, 1, file_buffer_size, vfp);
    }
    fclose(vfp);
    vfp = 0;

    unsigned int addrL = 0;
    unsigned short crc = 0;
    unsigned int countN = 0;

    int run_count = file_buffer_size / 255 + (file_buffer_size % 255 > 0 ? 1 : 0);
    for (int i = 0; i < run_count; i++)
    {

        crc = 0;

        if (i+1 == run_count)
            countN = file_buffer_size - i * 255;
        else
            countN = 255;

        addrL = i * 255;
        crc = (unsigned char)(addrL & 0xFF) + (unsigned char)((addrL >> 8) & 0xFF) + (unsigned char)((addrL >> 16) & 0xFF) + (unsigned char)((addrL >> 24) & 0xFF) + (unsigned char)(countN & 0xFF);

        for (int j = 0; j < countN; j++)
        {
            crc += (unsigned char)file_buffer[addrL + j];
        }
        crc += 1;


        message = "S3";
        int old_message_size = 0;
        //S 	��� 	���������� ������ 	����� 	������ 	����������� �����
        //S 	Type 	Byte Count 	Address 	Data 	Checksum 


        old_message_size = message.size();
        message.resize(old_message_size + 1 * 2);
        hex_buffer::str_to_hex((const char*)&countN, 1, &message[old_message_size], 1 * 2);


        old_message_size = message.size();
        message.resize(old_message_size + 4 * 2);
        hex_buffer::str_to_hex((const char*)&addrL, 4, &message[old_message_size], 4 * 2);

        old_message_size = message.size();
        message.resize(old_message_size + countN * 2);
        hex_buffer::str_to_hex((const char*)&file_buffer[addrL], countN, &message[old_message_size], countN * 2);

        old_message_size = message.size();
        message.resize(old_message_size + 1 * 2);
        char crc_char = (char)(crc & 0xff);
        hex_buffer::char_to_hex(crc_char, &message[old_message_size]);


        message += "\r\n";

        send_segment_message(tcpSocket, s, sa, message, confirmation_timeout, addrL);
    }

    message = "S3";
    int old_message_size = 0;
    //S 	��� 	���������� ������ 	����� 	������ 	����������� �����
    //S 	Type 	Byte Count 	Address 	Data 	Checksum 


    addrL += countN;

    countN = 0;
    old_message_size = message.size();
    message.resize(old_message_size + 1 * 2);
    hex_buffer::str_to_hex((const char*)&countN, 1, &message[old_message_size], 1 * 2);

    old_message_size = message.size();
    message.resize(old_message_size + 4 * 2);
    hex_buffer::str_to_hex((const char*)&addrL, 4, &message[old_message_size], 4 * 2);

    crc = (unsigned char)(addrL & 0xFF) + (unsigned char)((addrL >> 8) & 0xFF) + (unsigned char)((addrL >> 16) & 0xFF) + (unsigned char)((addrL >> 24) & 0xFF) + (unsigned char)(countN & 0xFF);
    crc += 1;
    old_message_size = message.size();
    message.resize(old_message_size + 1 * 2);
    hex_buffer::char_to_hex((const char)(crc & 0xff), &message[old_message_size]);

    message += "\r\n";

    send_segment_message(tcpSocket, s, sa, message, confirmation_timeout, addrL);

    closesocket(s);

    return;
    
}

bool send_segment_message(TCPSocket &tcpSocket, SOCKET &s, SOCKADDR_IN &sa, 
    const std::string & send_message,
    int confirmation_timeout, unsigned int addrL)
{
    bool result = false;
    std::atomic<bool> isSend = false;
    std::atomic<bool> isReceived = true;

    auto start_time = std::chrono::high_resolution_clock::now();
    auto end_time = std::chrono::high_resolution_clock::now();
    auto time = end_time - start_time;;

    int send_bytes_count = 0;
    int send_count = 0;

    isSend = false;
    std::string message = "";

    tcpSocket.onMessageReceived = [&isReceived, &start_time, &end_time, &time, &isSend, &message, &result, addrL](string received_message)
    {
        cout << "\nMessage from the Server: " << received_message;// << endl;
        end_time = std::chrono::high_resolution_clock::now();
        time = end_time - start_time;

        message += received_message;
        size_t position = 0;

        unsigned int _addrL = 0;

        if ((position = message.find("\r\n")) != string::npos)
        {
            isReceived = false;

            std::string parsed_string = message.substr(0, position);
            message = message.substr(position + 2, message.size() - 2 - position);

            parsed_string = hex_buffer(parsed_string, true).get_str();

            if (parsed_string.size() == 4)
            {
                memcpy(&_addrL, &parsed_string[0], 4);

                if (_addrL == addrL)
                    result = true;
            }
        }

        isSend = true;
        cout << "Read answer " << time / std::chrono::milliseconds(1) << " ms \n";


    };

    while (!isSend.load()&& !result)
    {
        send_count++;
        isSend = false;

        isReceived = true;
        
        start_time = std::chrono::high_resolution_clock::now();
        if
            (
                (send_bytes_count = sendto
                (
                    s,
                    send_message.c_str(), send_message.size(),
                    0,
                    (SOCKADDR*)&sa, sizeof(sa)
                )) == SOCKET_ERROR
                )
        {
            std::cout << "sendto error" << std::endl;
            break;
        }
        //std::this_thread::sleep_for((confirmation_timeout)*std::chrono::milliseconds(1));

        TCPSocket::ReceiveBytes(tcpSocket, isReceived, confirmation_timeout);
        
        if (send_count > 5)
            break;
    }

    tcpSocket.onMessageReceived = NULL;

    return result;
}