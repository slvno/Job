#pragma once
#include <cstddef>
#include <vector>

#include "basesocket.hpp"

/*
 	//S 	��� 	���������� ������ 	����� 	������ 	����������� �����
	//S 	Type 	Byte Count 	        Address Data 	Checksum 

Record types

The following table describes 10 possible S-records. S4 is reserved and not currently defined. S6 was originally reserved but was later redefined.
Record   	Record     Address      Data   Record
field       purpose    field        field  description	
---------------------------------------------------
S0 			Header 	   16-bit   	No     This record contains vendor specific ASCII text comment 
                       "0000"              represented as a series of hex digit pairs. It is common 
										   to see the data for this record in the format of a 
										   null-terminated string. The text data can be anything 
										   including a mixture of the following information:
										   file/module name, version/revision number, date/time, 
										   product name, vendor name, memory designator on PCB,
										   copyright notice, sign on.[3] It is common to
										   see: 48 44 52 which is the ASCII H, D, and R - "HDR".[4]
S1      	Data 	   16-bit
                       Address 	    Yes    This record contains data that starts at the 16-bit address field.
					                       [5][3] This record is typically used for 8-bit microcontrollers,
										   such as AVR, PIC, 8051, 68xx, 6502, 80xx, Z80. The number of
										   bytes of data contained in this record is "Byte Count Field" 
										   minus 3 (that is, 2 bytes for "16-bit Address Field" and 1 byte
										   for "Checksum Field").
S2 	        Data 	   24-bit
                       Address 	    Yes    This record contains data that starts at a 24-bit address.[5] 
					                       The number of bytes of data contained in this record is 
										   "Byte Count Field" minus 4 (that is, 3 bytes for "24-bit Address 
										   Field" and 1 byte for "Checksum Field").
S3 	        Data 	   32-bit
                       Address 	    Yes    This record contains data that starts at a 32-bit address.[5] 
					                       This record is typically used for 32-bit microcontrollers, such 
										   as ARM and 680x0. The number of bytes of data contained in 
										   this record is "Byte Count Field" minus 5 (that is, 4 bytes for
										   "32-bit Address Field" and 1 byte for "Checksum Field").
S4 	        Reserved  N/A 	        N/A    This record is reserved.
S5 	        Count 	  16-bit
                      Count 	    No 	   This optional record contains a 16-bit count of S1/S2/S3 records.
					                       [5] This record is used if the record count is less than or
										   equal to 65,535 (0xFFFF), otherwise S6 record would be used.
S6 	        Count 	  24-bit
                      Count 	    No 	   This optional record contains a 24-bit count of S1/S2/S3 records. This record is used if the record count is less than or equal to 16,777,215 (0xFFFFFF). If less than 65,536 (0x10000), then S5 record would be used. NOTE: This newer record is the most recent change (it may not be official).[5]
S7 	        Start     
            Address
			(Termination) 	
			          32-bit
					  Address 	    No 	   This record contains the starting execution location at a 
					                       32-bit address.[5][6] This is used to terminate a series of S3 
										   records. If a SREC file is only used to program a memory device 
										   and the execution location is ignored, then an address of zero 
										   could be used.
S8 	        Start 
            Address
			(Termination) 	
			          24-bit        
					  Address 	    No     This record contains the starting execution location at a 24-bit 
					                       address.[5][6] This is used to terminate a series of S2 records. 
										   If a SREC file is only used to program a memory device and the 
										   execution location is ignored, then an address of zero could be
										   used.
S9 	        Start 
            Address
			(Termination)
			          16-bit
					  Address 	    No     This record contains the starting execution location at a 16-bit 
					                       address.[5][6] This is used to terminate a series of S1 records.
										   [3] If a SREC file is only used to program a memory device and 
										   the execution location is ignored, then an address of zero could
										   be used.
*/

class hex_buffer
{
	std::string _str_data;
	std::string _hex_data;
public:
	//16 ������ ������(�� 2 ��������) HH ��������������� � char
	static char hex_to_char(const char* str)
	{ //�������� �� ����� str �� ��������
		unsigned char c;
		char a, b;
		if (!(a = str[0]) || !(b = str[1]))
		{
			// Incomplete, but valid
			return '%';
		}

		if (a >= 'a') a -= 32; //��������� ����� � �������� �������� 
		if (b >= 'a') b -= 32; //��������� ����� � �������� �������� 

		if (a >= '0' && a <= '9')
			c = a - '0';
		else
			if (a >= 'A' && a <= 'F')
				c = 10 + a - 'A';
			else
			{
				return '%';
				// Strange, but valid
			}

		c *= 16;

		if (b >= '0' && b <= '9')
			c += b - '0';
		else
			if (b >= 'A' && b <= 'F')
				c += 10 + b - 'A';
			else
			{
				return '%';
				// Strange, but valid

			}
		return c;
	}

	//char ��������������� � 16 ������ ������(2 �������) HH  
	static void char_to_hex(char ch, char* str)
	{ //�������� �� ����� str �� ��������
		unsigned char c = 0;
		char a = (ch >> 4) & 0x0F,
			b = ch & 0x0F;
		/*
		if (a >= 0 && a <= 9)
			a = a + '0';
		else
			if (a >= 0x0A && a <= 0x0F)
				a = 'A' + a - 10;
        */
		str[0] = "0123456789ABCDEF"[a & 15];
		/*
		if (b >= 0 && b <= 9)
			b = b + '0';
		else
			if (b >= 0x0A && b <= 0x0F)
				b = 'A' + b - 10;
		*/
		str[1] = "0123456789ABCDEF"[b & 15];
	}

	static bool hex_to_str(const char* hex_str, int hex_str_size, char* str, int str_size)
	{
		int i = 0;

		if (hex_str_size % 2 != 0)
			return false;

		for (i = 0; (i < hex_str_size / 2) && (i < str_size); i++)
		{
			str[i] = hex_to_char(&hex_str[i*2]);
		}

		return true;
	}

	static bool str_to_hex(const char* str, int str_size, char* hex_str, int hex_str_size)
	{
		int i = 0;

		if (str_size * 2 > hex_str_size)
			return false;

		for (i = 0; (i < str_size ) && (2*i < hex_str_size); i++)
		{
			char_to_hex(str[i], &hex_str[2 * i]);;
		}

		return true;
	}


	hex_buffer(const std::string& str_data, bool str_data_is_hex)
	{
		if (str_data_is_hex)
		{
			_hex_data = str_data;
			_str_data.resize(_hex_data.size() / 2 );

			hex_to_str(_hex_data.c_str(), _hex_data.size(), &_str_data[0], _str_data.size());
		}
		else
		{
			_str_data = str_data;
			_hex_data.resize(_str_data.size() * 2 );

			str_to_hex(&str_data[0], _str_data.size(), &_hex_data[0], _hex_data.size());
		}
	}

	std::string get_str()
	{
		return _str_data;
	}

	const size_t get_str_size()
	{
		return _str_data.size();
	}

	std::string get_hex()
	{
		return _hex_data;
	}

	const size_t get_hex_size()
	{
		return _hex_data.size();
	}

};
class srec
{
public:
	unsigned int
		addrL;
	char cksmB;     /* checksum of addr, count, & data length */
	unsigned int countN;              /* Number of bytes represented in record */

	//S 	��� 	���������� ������ 	����� 	������ 	����������� �����
	//S 	Type 	Byte Count 	Address 	Data 	Checksum 
	bool is_srec;

	std::string hex_data;
	std::string str_data;
	char srec_type;
	int oheadN;

	srec() 
	{ 
		hex_data.resize(0);
		addrL = 0;
		cksmB = 0;
		countN = 0;
		oheadN = 0;
		srec_type = 0;
		is_srec = false;
	}

	unsigned short
		bytereorder16(unsigned long value)
	{
		return 
			(((value & 0xff000000) >> 24) |
			((value & 0x00ff0000) >> 8));
	}

	unsigned long
		bytereorder24(unsigned long value)
	{

		return
			((value & 0xff000000) >> 24) |
			((value & 0x00ff0000) >> 8) |
			((value & 0x0000ff00) << 8)
			//|((value & 0x000000ff) << 24)
			;
	}

	unsigned long
		bytereorder32(unsigned long value)
	{
		
		return
			((value & 0xff000000) >> 24) |
			((value & 0x00ff0000) >> 8) |
			((value & 0x0000ff00) << 8) |
			((value & 0x000000ff) << 24);
	}

	srec(const std::string &buffer): srec ()
	{
		if (buffer[0] == 'S')
		{
			is_srec = true;


			unsigned short crc = 0;
			hex_data.resize(0);

			switch (srec_type = buffer[1])       /* examine 2nd character on the line */
			{
			case '1':                   /* 16 bit address field */
				if (sscanf(buffer.c_str(), "S1%2x%4lx", &countN, &addrL) != 2)
				{
					is_srec = false;
					//fprintf(stderr, "Error in line %d of hex file\n", Record_Nb);
					return;       /* Flag error in S1 record */
				}
				addrL = bytereorder16(addrL);
				crc = (unsigned char)(addrL & 0xFF) + (unsigned char)((addrL >> 8) & 0xFF) + (unsigned char)(countN & 0xFF);

				oheadN = 3;             /* 2 address + 1 checksum */
				break;

			case '2':                   /* 24 bit address field */
				if (sscanf(buffer.c_str(), "S2%2x%6lx", &countN, &addrL) != 2)
				{
					is_srec = false;
					return;       /* Flag error in S2 record */
				}
				addrL = bytereorder24(addrL);
				crc = (unsigned char)(addrL & 0xFF) + (unsigned char)((addrL >> 8) & 0xFF) + (unsigned char)((addrL >> 16) & 0xFF) + (unsigned char)(countN & 0xFF);

				oheadN = 4;             /* 3 address + 1 checksum */
				break;

			case '3':                   /* 32 bit address field */
				if (sscanf(buffer.c_str(), "S3%2x%8lx", &countN, &addrL) != 2)
				{
					is_srec = false;
					return;       /* Flag error in S3 record */
				}
				addrL = bytereorder32(addrL);
				crc = (unsigned char)(addrL & 0xFF) + (unsigned char)((addrL >> 8) & 0xFF) + (unsigned char)((addrL >> 16) & 0xFF) + (unsigned char)((addrL >> 24) & 0xFF) + (unsigned char)(countN & 0xFF);
				oheadN = 5;             /* 4 address + 1 checksum */
				break;

			default:                    /* ignore all but S1,2,3 records. */
				return;
			}

			int count_copy_bytes = buffer.size() - (2 + oheadN * 2);
			hex_data.resize( count_copy_bytes);

			if (count_copy_bytes > 0)
				hex_data = buffer.substr((2 + oheadN * 2), count_copy_bytes);

			cksmB = (unsigned char)hex_buffer::hex_to_char(&hex_data[countN * 2]);

			hex_data.resize(hex_data.size() - 2 >= 0 ? hex_data.size() - 2 : 0);

			str_data = hex_buffer(hex_data, true).get_str();
					
			for (int i = 0; i < str_data.size(); i++)
				crc += (unsigned char)str_data[i];

			crc += 1;

			char crc_char = (char)(crc & 0xff);
			if (crc_char != cksmB)
				is_srec = false;
			else
				is_srec = true;
		}
	}

	void write(char* buffer, size_t buffer_size)
	{
		if (is_srec && (str_data.size() > 0) && (addrL + str_data.size() < buffer_size))
			memcpy(&buffer[addrL], str_data.c_str(), str_data.size());
	}
};

