#pragma once

#include "basesocket.hpp"
#include <string>
#include <string.h>
#include <functional>
#include <thread>

class TCPSocket : public BaseSocket
{
public:
    // Event Listeners:
    std::function<void(std::string)> onMessageReceived;
    std::function<void(const char*, int)> onRawMessageReceived;
    std::function<void(int)> onSocketClosed;

    explicit TCPSocket(FDR_ON_ERROR, int socketId = -1) : BaseSocket(onError, TCP, socketId){}

    // Send TCP Packages
    int Send(const char *bytes, size_t byteslength)
    {
        if (this->isClosed.load())
            return -1;

        int sent = 0;
        if (this->sock != 0 && ((sent = send(this->sock, bytes, byteslength, 0)) < 0))
        {
            perror("send");
        }
        return sent;
    }
    int Send(std::string message) { return this->Send(message.c_str(), message.length()); }

    void Connect(std::string host, uint16_t port, std::function<void()> onConnected = [](){}, FDR_ON_ERROR)
    {
        struct addrinfo hints, *res, *it;
        memset(&hints, 0, sizeof(hints));
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;

        // Get address info from DNS
        int status;
        if ((status = getaddrinfo(host.c_str(), NULL, &hints, &res)) != 0) {
            std::wstring t = gai_strerror(status);
            onError(errno, "Invalid address." + std::string(t.begin(), t.end()));
            return;
        }

        for(it = res; it != NULL; it = it->ai_next)
        {
            if (it->ai_family == AF_INET) { // IPv4
                memcpy((void*)(&this->address), (void*)it->ai_addr, sizeof(sockaddr_in));
                break; // for now, just get first ip (ipv4).
            }
        }

        freeaddrinfo(res);

        this->Connect((uint32_t)this->address.sin_addr.s_addr, port, onConnected, onError);
    }
    void Connect(uint32_t ipv4, uint16_t port, std::function<void()> onConnected = [](){}, FDR_ON_ERROR)
    {
        this->address.sin_family = AF_INET;
        this->address.sin_port = htons(port);
        this->address.sin_addr.s_addr = ipv4;

        this->setTimeout(5);

        // Try to connect.
        if (this->sock != 0 && (connect(this->sock, (const sockaddr *)&this->address, sizeof(sockaddr_in)) < 0))
        {
            onError(errno, "Connection failed to the host.");
            this->setTimeout(0);
            return;
        }

        this->setTimeout(0);

        // Connected to the server, fire the event.
        onConnected();

        // Start listening from server:
        //this->Listen();
    }

    void Listen()
    {
        std::thread t(TCPSocket::Receive, this);
        t.detach();
    }

    void setAddressStruct(sockaddr_in addr) {this->address = addr;}
    sockaddr_in getAddressStruct() const {return this->address;}

    bool deleteAfterClosed = false;
    
    static void ReceiveBytes(TCPSocket& socket, std::atomic<bool> &isReceived, int confirmation_timeout)
    {
        char tempBuffer[BaseSocket::BUFFER_SIZE + 1];
        int messageLength;
        struct timeval tv;
        fd_set readfds;

        tv.tv_sec = 0;
        tv.tv_usec = 1000; //1ms

        if (socket.sock != 0)
        {
            do
            {
                FD_ZERO(&readfds);
                FD_SET(socket.sock, &readfds);

                // writefds � exceptfds ��� �� �����:
                select(socket.sock + 1, &readfds, NULL, NULL, &tv);

                if (FD_ISSET(socket.sock, &readfds) && 
                   ((messageLength = recv(socket.sock, tempBuffer, BaseSocket::BUFFER_SIZE, 0)) > 0))

                {
                    tempBuffer[messageLength] = '\0';

                    if (socket.onMessageReceived)
                        socket.onMessageReceived(std::string(tempBuffer, messageLength));

                    if (socket.onRawMessageReceived)
                        socket.onRawMessageReceived(tempBuffer, messageLength);

                    memset(tempBuffer, 0, BaseSocket::BUFFER_SIZE + 1);
                }

                confirmation_timeout--;
                if (confirmation_timeout <= 0)
                {
                    
                    break;
                }
            } while (isReceived.load());
        }
    }

private:
    static void Receive(TCPSocket *socket)
    {
        char tempBuffer[BaseSocket::BUFFER_SIZE+1];
        int messageLength;

        if (socket->sock != 0)
        {
            while ((messageLength = recv(socket->sock, tempBuffer, BaseSocket::BUFFER_SIZE, 0)) > 0)
            {
                tempBuffer[messageLength] = '\0';

                if (socket->onMessageReceived)
                    socket->onMessageReceived(std::string(tempBuffer, messageLength));

                if (socket->onRawMessageReceived)
                    socket->onRawMessageReceived(tempBuffer, messageLength);

                memset(tempBuffer, 0, BaseSocket::BUFFER_SIZE+1);
            }

            socket->Close();

            if (socket->onSocketClosed)
                socket->onSocketClosed(errno);

            if (socket->deleteAfterClosed && socket != nullptr)
                delete socket;
        }
    }

    void setTimeout(int seconds)
    {
        struct timeval tv {};
        tv.tv_sec = seconds;
        tv.tv_usec = 0;

        setsockopt(this->sock, SOL_SOCKET, SO_RCVTIMEO, (char *)&tv, sizeof(tv));
        setsockopt(this->sock, SOL_SOCKET, SO_SNDTIMEO, (char *)&tv, sizeof(tv));
    }
};