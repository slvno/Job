

//------------------------------------------------------------------------------
#include <winsock2.h>
#include <ws2tcpip.h>
#include <iphlpapi.h>
#include <stdio.h>

#pragma comment(lib, "Ws2_32.lib")

#include <conio.h>
#include <iostream>
//------------------------------------------------------------------------------
#include <csignal>
#include <cstdlib>
#include <cstring>

#include <vector>

//#include <unistd.h>
#include <io.h>
#include <stdio.h>
#include "tcpserver.hpp"
#include <iostream>
#include <signal.h>

#include "srec.h"
using namespace std;
static TCPServer *_tcpServer = 0;

static void clean_this()
{
    if (_tcpServer != NULL)
    {
        _tcpServer->Close();
        WSACleanup();
    }
}
// The actual signal handler
 void handleSignal(int sig) {
  // Cannot use printf() - not async-signal-safe 
  // For simplicity I use a single call to write here
  // though it is not guaranteed to write the whole message
  // You need to wrap it in a loop

  // Die only on Ctrl+C
  if(sig == SIGINT) {
    const char *msg = "Die\n";
    write(2, msg, ::strlen(msg));
    // Reset to use the default handler to do proper clean-up
    // If you want to call the default handler for every singal
    // You can avoid the call below by adding SA_RESETHAND to sa_flags
	
	clean_this();
	
    signal(sig, SIG_DFL);
    raise(sig);
    return;
  }

  // Here we want to handle the signal ourselves
  // We have all the info available
  const char *msg = "Continue\n";
  write(2, msg, ::strlen(msg));
}
void waiting_clients_connect(const std::string &IP, int Port, const std::string &Folder);
int main(int argc, char* argv[]) {
    // A vector of all signals that lead to process termination by default
  // (see man -s 7 signal)
  const int TERM_SIGNALS[] = {
         SIGINT, SIGILL, SIGABRT, SIGFPE, SIGSEGV,
         SIGTERM};

  // Register the signal event handler for every terminating signal
  for (auto sig : TERM_SIGNALS) {
      signal(sig, handleSignal);
  }

	//про параллельную загрузку файлов ничего не сказано в ТЗ, поэтому делаем однопоточный сервер
    std::string IP;
    int Port;
    std::string Folder;
	
	if (argc != 4)
	{
		std::cout << "Get files from udp port\n";
		std::cout << "Usage:\n" << argv[0] << " server_ip_adress server_port file_dir_path\n";
        exit(-1);
	}
	
	IP = argv[1];
    Port = atoi(argv[2]);
	Folder = argv[3];
	
    std::cout << "ip: " << IP << "\n";
    std::cout << "port: "<< Port << "\n";
    std::cout << "folder: "<< Folder << "\n";
	
    // Initialize Winsock
    WSADATA wsaData;
    int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != 0) {
        printf("WSAStartup failed with error: %d\n", iResult);
        return 1;
    }


	waiting_clients_connect(IP, Port, Folder);

    for (auto sig : TERM_SIGNALS) {
        signal(sig, SIG_DFL);
    }

    WSACleanup();
}

void get_file(TCPSocket* newClient, const std::string &IP, int Port, const std::string &Folder, const std::string &file_name);

std::string replace_all(std::string inout, std::string what, std::string with)
{
    std::size_t count{};
    for (std::string::size_type pos{};
         inout.npos != (pos = inout.find(what.data(), pos, what.length()));
         pos += with.length(), ++count) {
        inout.replace(pos, what.length(), with.data(), with.length());
    }
    return inout;
}

void waiting_clients_connect(const std::string &IP, int Port, const std::string &Folder)
{
    // Initialize server socket..
    TCPServer tcpServer;
    _tcpServer = &tcpServer;
    int udp_port = -1;
    std::string file_name = "";
    std::string received_string = "";
    std::atomic<bool> isReceived = true;

    // When a new client connected:
    tcpServer.onNewConnection = [&](TCPSocket *newClient) 
    {
        cout << "New client: [";
        cout << newClient->remoteAddress() << ":" << newClient->remotePort() << "]" << endl;

        newClient->onMessageReceived = [&isReceived, &newClient, Folder, IP, &udp_port, &file_name, &received_string](string message) {
            cout << newClient->remoteAddress() << ":" << newClient->remotePort() << " => " << message << endl;
            //newClient->Send("OK!");
            received_string += message;
            int position = 0;

            if ((udp_port == -1) && ((position = received_string.find("\r\n")) != string::npos))
                {
                    udp_port = atoi(received_string.substr(0, position).c_str());//replace_all(message, "\r\n", "\0\0").c_str());
                    received_string = received_string.substr(position + 2, received_string.size() - (position + 2));

                    if (received_string.size() == 0)
                      return;
                }

             if ((file_name.size() == 0) && ((position = received_string.find("\r\n")) != string::npos))
                {
                    file_name = //&replace_all(message, "\n", "\0").c_str()[std::to_string(udp_port).length() + 1];
                        received_string.substr(0, position);//replace_all(message, "\r\n", "\0\0").c_str());
                        received_string = received_string.substr(position + 2, received_string.size() - (position + 2));
                }

             if ((udp_port != -1) && (file_name.size() != 0))
             {
                 isReceived = false;

              //   get_file(newClient, IP, udp_port, Folder, file_name);
                 std::thread t(get_file, newClient, IP, udp_port, Folder, file_name);
                 t.detach();

                 udp_port = -1;

                 file_name = "";
             }
            
        };
        
        // If you want to use raw bytes
        /*
        newClient->onRawMessageReceived = [newClient](const char* message, int length) {
            cout << newClient->remoteAddress() << ":" << newClient->remotePort() << " => " << message << "(" << length << ")" << endl;
            newClient->Send("OK!");
        };
        */
        
        newClient->onSocketClosed = [newClient](int errorCode) {
            cout << "Socket closed:" << newClient->remoteAddress() << ":" << newClient->remotePort() << " -> " << errorCode << endl;
            cout << flush;
        };

        TCPSocket::ReceiveBytes(*newClient, isReceived, INT32_MAX);        
    };

    // Bind the server to a port.
    tcpServer.Bind(IP.c_str(), Port, [](int errorCode, string errorMessage) {
        // BINDING FAILED:
        cout << errorCode << " : " << errorMessage << endl;
    });

    // Start Listening the server.
    tcpServer.Listen([](int errorCode, string errorMessage) {
        // LISTENING FAILED:
        cout << errorCode << " : " << errorMessage << endl;
    });

    // You should do an input loop so the program will not terminated immediately:
    string input;
    getline(cin, input);
    while (input != "exit")
    {
        getline(cin, input);
    }

    // Close the server before exiting the program.
    tcpServer.Close();
    WSACleanup();
    return ;
}

void get_file(TCPSocket* newClient, const std::string &IP, int Port, const std::string &Folder,
    const std::string &file_name)
{
	/*
    WSADATA wsa_data;
    if (WSAStartup(0x101, &wsa_data) || wsa_data.wVersion != 0x101)
    {
        std::cout << "WSAStartup error" << std::endl;
        return -1;
    }
 */
    SOCKET s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (s == INVALID_SOCKET)
    {
        std::cout << "socket error" << std::endl;
        return ;
    }
 
    SOCKADDR_IN sa{};
    sa.sin_family = AF_INET;
    sa.sin_port = htons(Port);
    sa.sin_addr.S_un.S_addr = inet_addr(IP.c_str());
 
    if (::bind(s, (SOCKADDR *)&sa, sizeof(sa)) == SOCKET_ERROR)
    {
        std::cout << "bind error" << std::endl;
	    closesocket(s);
        return ;
    }
 
    SOCKADDR_IN nsa{};
    int sizeof_nsa = sizeof(nsa);
 
    char buffer[1024+512];
    int buffer_size = sizeof(buffer);
    int bytes_get_from_udp_socket = 0;
    std::string received_string = "";
    int position = 0;

    char *file_buffer = NULL;
    int file_buffer_size = 0;

    while (!kbhit())
    {
        memset(buffer, 0, sizeof(buffer));
        if
        (
            (bytes_get_from_udp_socket = recvfrom
            (
                s,
                buffer, buffer_size,
                0,
                (SOCKADDR *)&nsa, &sizeof_nsa
            )) == SOCKET_ERROR
        )
        {
            std::cout << "recvfrom error" << std::endl;
            break;
        }
        if (bytes_get_from_udp_socket <= 0)
            break;

        int old_size_received_string = received_string.size();
        
        received_string.resize(old_size_received_string + bytes_get_from_udp_socket);
        memcpy(&received_string[old_size_received_string], buffer, bytes_get_from_udp_socket);
        //received_string += buffer;

        srec* rec = NULL;
        if ((position = received_string.find("\r\n")) != string::npos)
        {
            std::string parsed_string = received_string.substr(0, position);

            rec = new srec(parsed_string);
            received_string = received_string.substr(position + 2, received_string.size() - (position + 2));
        }

        if (rec != NULL)
        {            
            if (rec->is_srec)
            {
                if (file_buffer == NULL)
                    file_buffer = new char[10 * 1024 * 1024];

                rec->write(file_buffer, 10 * 1024 * 1024);
                if (file_buffer_size < rec->addrL + rec->countN)
                    file_buffer_size = rec->addrL + rec->countN;

                int sent = 0;

                char hex_str[10] = { 0,0,0,0,0,0,0,0,0,0 };
                int hex_str_size = 10;

                hex_buffer::str_to_hex((const char*)&rec->addrL, rec->oheadN - 1, hex_str, hex_str_size);
                hex_str_size = strlen(hex_str);

                hex_str[hex_str_size] = '\r';
                hex_str[hex_str_size+1] = '\n';
                hex_str_size += 2;

                if (newClient->Send(hex_str, hex_str_size) < 0)
                {
                    perror("send package answer - ");
                }

                if (rec->countN == 0)
                {
                    delete rec;
                    break;
                }
            }

            delete rec;
        }

        std::cout << inet_ntoa(nsa.sin_addr) << ">" << buffer << std::endl;
        memset(buffer, 0, buffer_size);
    }
 
    if (file_buffer != NULL)
    {
        std::string _file_name = Folder +(std::string)"\\"+ file_name;
        FILE *vfp = fopen(_file_name.c_str(), "wb");
        if (!vfp)
            perror("Error: open file_name");

        fwrite(file_buffer, 1, file_buffer_size, vfp);
        fclose(vfp);
        vfp = 0;

        delete[] file_buffer;
    }

    closesocket(s);
    //newClient->Close();
    //delete newClient;
    //newClient = NULL;
    //WSACleanup();
 
    return ;
}