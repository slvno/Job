#include "databaseworker.h"
#include <QDebug>
#include <QSqlError>
#include <QSqlDriver>
#include <QDebug>
#include <stdexcept>

DatabaseWorker::DatabaseWorker(QObject *parent) : QObject(parent), m_isListening(false)
{}

DatabaseWorker::~DatabaseWorker()
{
    stop();
}

void DatabaseWorker::start(const QString &hostname, int port, const QString &dbname, const QString &user, const QString &passwd)
{
    if(m_isListening){
        return;
    }

    m_database = QSqlDatabase::addDatabase("QPSQL"); // Драйвер для PostgreSQL
    m_database.setHostName(hostname);
    m_database.setPort(port);
    m_database.setDatabaseName(dbname);
    m_database.setUserName(user);
    m_database.setPassword(passwd);

    if(!m_database.open()){
        qWarning() << "Unable to open database connection." << m_database.lastError().text();;
        return;
    }

    QSqlQuery query(m_database);
    query.exec("LISTEN my_notification_channel"); // регистрируемся на канал 'my_notification_channel'

    m_isListening = true;

    // Начальная загрузка данных
    query.exec("SELECT * FROM my_table ORDER BY id ASC");
    QStringList initialData;
    while(query.next()){
        initialData.append(query.value(0).toString()); // ID
        initialData.append(query.value(2).toString()); // Flag
        initialData.append(query.value(1).toString()); // Data
    }
    emit newDataAvailable(initialData);

    //connect(&m_database, &QSqlDatabase::notification, this, &DatabaseWorker::listenForNotifications);
    // Получаем экземпляр текущего драйвера
    auto driver = m_database.driver();
    if (!driver || !driver->hasFeature(QSqlDriver::EventNotifications)) {
        qWarning() << "Поддержка уведомлений отсутствует!";
        return;
    }

    // Регистрация канала уведомлений (если используется PostgreSQL)
    QString channel = "my_notification_channel";
    bool success = driver->subscribeToNotification(channel.toUtf8());
    if (!success) {
        qWarning() << "Ошибка подписки на канал:" << driver->lastError().text();
        return;
    }

    // Подписываемся на сигнал уведомлений
    QObject::connect(driver, SIGNAL(notification(const QString&)), this, SLOT(listenForNotifications(const QString&)));


}

void DatabaseWorker::stop(){
    if(m_isListening){
        QSqlQuery query(m_database);
        query.exec("UNLISTEN my_notification_channel"); // не регистрируемся на канал 'my_notification_channel'

        m_database.close();
        m_isListening = false;
    }
}
void DatabaseWorker::listenForNotificationsPayload(const QString& name, QSqlDriver::NotificationSource source, const QVariant& payload)
{

}


void DatabaseWorker::listenForNotifications(const QString& name){
    if (name.compare("my_notification_channel", Qt::CaseSensitive) == 0) {

        // Получаем уведомление и обрабатываем событие
        QSqlQuery query(m_database);
        //query.exec("REFRESH MATERIALIZED VIEW my_view"); // Пример действия после уведомления
        query.exec("SELECT * FROM my_table ORDER BY id ASC");

        QStringList updatedData;
        while (query.next()) {
            updatedData.append(query.value(0).toString()); // ID
            updatedData.append(query.value(1).toString()); // Flag
            updatedData.append(query.value(2).toString()); // Data
        }
        emit newDataAvailable(updatedData);
    }
} 

void DatabaseWorker::insertRecords()
{
    if (m_isListening) {
        QSqlDatabase db = m_database;//QSqlDatabase::database(); // Используем существующую базу данных

        if (!db.isOpen()) {
            qWarning() << "Ошибка подключения к базе данных";
            return;
        }

        bool transactionSuccess = false;

        try {
            // Начинаем транзакцию
            db.transaction();

            QSqlQuery query(db);
            for (int i = 0; i < 1000; ++i) {
                QString value = QString("Record %1").arg(i + 1); // Генерируем уникальное значение для каждой записи
                query.prepare("INSERT INTO my_table (value, flag) VALUES (:value, :flag)");
                query.bindValue(":value", value);
                query.bindValue(":flag", true); // Устанавливаем флаг True сразу
                if (!query.exec()) {
                    throw std::runtime_error(query.lastError().text().toStdString());
                }
            }

            // Завершаем транзакцию успешно
            db.commit();
            transactionSuccess = true;
        }
        catch (const std::exception& e) {
            qCritical() << "Ошибка при выполнении транзакции:" << QString::fromStdString(e.what());
            db.rollback(); // Откатываем изменения в случае ошибки
        }

        if (transactionSuccess)
            qInfo() << "Записи успешно добавлены!";
    }
}

void DatabaseWorker::changeFlagsToFalse()
{
    if (m_isListening) {
        QSqlDatabase db = m_database;//QSqlDatabase::database();

        if (!db.isOpen()) {
            qWarning() << "Ошибка подключения к базе данных";
            return;
        }

        bool transactionSuccess = false;

        try {
            // Начинаем транзакцию
            db.transaction();

            QSqlQuery query(db);
            query.prepare("UPDATE my_table SET flag = ?");
            query.addBindValue(false); // Меняем флаг на False

            if (query.exec())
                qInfo() << "Флаги успешно обновлены.";
            else
                qCritical() << "Ошибка обновления флажков:" << query.lastError().text();

            // Завершаем транзакцию успешно
            db.commit();
            transactionSuccess = true;
        }
        catch (const std::exception& e) {
            qCritical() << "Ошибка при выполнении транзакции:" << QString::fromStdString(e.what());
            db.rollback(); // Откатываем изменения в случае ошибки
        }

        if (transactionSuccess)
            qInfo() << "Записи успешно обновлены!";
    }
}

void DatabaseWorker::insert_update_records()
{
    if (m_isListening) {
        QSqlDatabase db = m_database;//QSqlDatabase::database();

        if (!db.isOpen()) {
            qWarning() << "Ошибка подключения к базе данных";
            return;
        }

        // Получаем уведомление и обрабатываем событие
        QSqlQuery query(m_database);
        //query.exec("REFRESH MATERIALIZED VIEW my_view"); // Пример действия после уведомления
        query.exec("SELECT count(*) FROM my_table");

        if (query.next()) {
            if (query.value(0).toInt() < 1000)
            {
                query.exec("SELECT count(*) FROM my_table where flag = True");
                if (query.next()) {
                    if (query.value(0).toInt() == 1000)
                        changeFlagsToFalse();
                    else
                        qInfo() << "В таблице найдено колличество записей отличное от 1000 ! \nГы-Гы :)";
                }
            }
            else
                insertRecords();
        }
    }
}