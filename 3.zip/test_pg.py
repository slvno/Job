import asyncpg_lite as asyncpg
import logging
import re
import typing
import  sqlalchemy as sa
import  sqlalchemy.ext.asyncio
import  sqlalchemy.orm
import  sqlalchemy.sql
import  sqlalchemy.dialects.postgresql
import urllib.parse

# from asyncpg_lite import DatabaseManager
from decouple import config
import asyncio
# from sqlalchemy import BigInteger, String, Integer

#pg_link = config('PG_LINK', default='postgresql://telegram_user:telegram_password@10.0.2.15:5432/telegram_db')
pg_link = config('PG_LINK', default='postgresql://postgres:********@localhost:5432/test')


deletion_password = config('ROOT_PASS', default='1234')
#auth_params={'host': '10.0.2.15', 'port': 5423, 'user': 'telegram_user', 'password': 'telegram_password', 'database': 'telegram_db'}
auth_params={'host': 'localhost', 'port': 5423, 'user': 'postgres', 'password': '********', 'database': 'test'}

async def main():
    
	
    #db_manager = DatabaseManager(db_url=pg_link, deletion_password=deletion_password, auth_params=auth_params, echo=True)
    #db_manager = DatabaseManager(db_url=pg_link, deletion_password=deletion_password, echo=True)
    db_manager = asyncpg.DatabaseManager( deletion_password=deletion_password, auth_params=auth_params)
    # Далее используем db_manager...
    #Вариант подключения с указанием данных для подключения

    #Для этого при инициации объекта менеджера необходимо передать параметр auth_params. Это питоновский словарь, содержащий такие ключи:
    
      
    async with db_manager:
        #pass
        print ('ok')
        columns = [
            {"name": "user_id", "type": sa.BigInteger, "options": {"primary_key": True, "autoincrement": False}},
            {"name": "user_name", "type": sa.String, "options": {"default": 'Vasya', 'unique': True}},
            {"name": "user_surname", "type": sa.String},
            {"name": "user_age", "type": sa.Integer},
        ] 
	    
        await db_manager.create_table(table_name="new_users", columns=columns) 
	