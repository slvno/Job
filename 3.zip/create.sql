CREATE TABLE my_table (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    value TEXT NOT NULL DEFAULT '',
    flag BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE OR REPLACE FUNCTION notify_my_table_change()
RETURNS TRIGGER AS $$
BEGIN
    PERFORM pg_notify('my_notification_channel', row_to_json(NEW)::text);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE TRIGGER my_table_trigger
AFTER INSERT OR UPDATE OR DELETE ON my_table
FOR EACH ROW EXECUTE PROCEDURE notify_my_table_change();