#include <windows.h>
#include "mainwindow.h"
#include <QtGui>
#include <QLabel>
#include <QScrollArea>
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
  QApplication app(argc, argv);
  
  //QApplication::setStyle(QStyleFactory::create("Plastique"));
  ///QApplication::setPalette(QApplication::style()->standardPalette());

  QTextCodec *tCodec = QTextCodec::codecForName("CP1251");
  QTextCodec::setCodecForLocale(tCodec);
  
  //QWidget *w = new QWidget();

  //w->setGeometry(0,25,1010,700);
  //w->show();
  
  //QScrollBar *vertical_sb_ = new QScrollBar(w); 
  //QScrollBar *horizontal_sb_ = new QScrollBar(w);

  //MainWindow *t = new MainWindow(w);


  //vertical_sb_->setMaximum(700);
  //horizontal_sb_->setMaximum(1010);
  
  
  
  //t->show();
  MainWindow t;
  t.show();

  return app.exec();

}
