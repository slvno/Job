 #ifndef DATABASEWORKER_H
#define DATABASEWORKER_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QStringList>
#include <QSqlDriver>

class DatabaseWorker : public QObject
{
    Q_OBJECT
public:
    explicit DatabaseWorker(QObject *parent = nullptr);
    ~DatabaseWorker();

signals:
    void finished();
    void newDataAvailable(const QStringList &data);
    void work_with_db();
public slots:

    void start(const QString& hostname, int port, const QString& dbname, const QString& user, const QString& passwd);
    void stop();
    void insert_update_records();
private slots:
    void listenForNotifications(const QString& name);
    void listenForNotificationsPayload(const QString& name, QSqlDriver::NotificationSource source, const QVariant& payload);    

private:
    QSqlDatabase m_database;
    bool m_isListening;
protected:
    void insertRecords();
    void changeFlagsToFalse();
    
};

#endif // DATABASEWORKER_H