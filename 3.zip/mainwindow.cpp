 #include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Создаем рабочую модель для отображения данных
    tableModel = new QStandardItemModel(0, 3, this);
    tableModel->setHorizontalHeaderLabels({ "ID", "Flag", "Data" });
    ui->tableView->setModel(tableModel);

    // Инициализация рабочего потока
    workerThread = new QThread(this);
    databaseWorker = new DatabaseWorker();
    databaseWorker->moveToThread(workerThread);

    // Соединяем сигналы и слоты
    connect(ui->pushButton_start, &QPushButton::clicked, this, &MainWindow::on_pushButton_start_clicked);
    connect(ui->pushButton_stop, &QPushButton::clicked, this, &MainWindow::on_pushButton_stop_clicked);
    connect(databaseWorker, &DatabaseWorker::work_with_db, databaseWorker, &DatabaseWorker::insert_update_records);

    workerThread->start();
}

MainWindow::~MainWindow()
{
    delete ui;
    workerThread->exit();
    workerThread->wait();
}

void MainWindow::on_pushButton_start_clicked()
{
    QString hostname = ui->lineEdit_host->text();
    int port = ui->lineEdit_port->text().toInt();
    QString dbname = ui->lineEdit_dbname->text();
    QString username = ui->lineEdit_username->text();
    QString passwd = ui->lineEdit_password->text();

    QMetaObject::invokeMethod(databaseWorker, "start",
                              Q_ARG(QString, hostname),
                              Q_ARG(int, port),
                              Q_ARG(QString, dbname),
                              Q_ARG(QString, username),
                              Q_ARG(QString, passwd));

    QMetaObject::invokeMethod(databaseWorker, "work_with_db");
}

void MainWindow::on_pushButton_stop_clicked()
{
    QMetaObject::invokeMethod(databaseWorker, "stop");
}

void MainWindow::refreshTable(const QStringList &data)
{
    tableModel->clear();
    for(int i=0;i<data.size();i+=3){
        QList<QStandardItem*> items;
        items.append(new QStandardItem(data[i]));
        items.append(new QStandardItem(data[i+1]));
        items.append(new QStandardItem(data[i+2]));
        tableModel->appendRow(items);
    }
}